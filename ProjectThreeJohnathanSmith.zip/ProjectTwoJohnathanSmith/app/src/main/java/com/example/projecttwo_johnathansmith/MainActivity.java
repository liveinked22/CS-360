package com.example.projecttwo_johnathansmith;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 200;

    private EditText etGoalWeight, etPhoneNumber, etWeightInput;
    private Button btnLogWeight;
    private ListView lvWeightLogs;

    private DatabaseHelper dbHelper;
    private int loggedInUserId;

    private ArrayList<String> logDisplayList;
    private ArrayList<Integer> logIdList;
    private ArrayAdapter<String> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        dbHelper = new DatabaseHelper(this);
        loggedInUserId = getIntent().getIntExtra("USER_ID", -1);

        if (loggedInUserId == -1) {
            Toast.makeText(this, "Login error. Please sign in again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        etGoalWeight = findViewById(R.id.etGoalWeight);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etWeightInput = findViewById(R.id.etWeightInput);
        btnLogWeight = findViewById(R.id.btnLogWeight);
        lvWeightLogs = findViewById(R.id.lvWeightLogs);

        logDisplayList = new ArrayList<>();
        logIdList = new ArrayList<>();
        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, logDisplayList);
        lvWeightLogs.setAdapter(listAdapter);

        refreshWeightLogList();

        btnLogWeight.setOnClickListener(v -> saveWeightLog());

        lvWeightLogs.setOnItemClickListener((parent, view, position, id) -> {
            int selectedLogId = logIdList.get(position);
            showUpdateDialog(selectedLogId);
        });

        lvWeightLogs.setOnItemLongClickListener((parent, view, position, id) -> {
            int selectedLogId = logIdList.get(position);
            confirmDelete(selectedLogId);
            return true;
        });

        checkAndRequestSmsPermission();
    }

    private void saveWeightLog() {
        String weightText = etWeightInput.getText().toString().trim();

        if (weightText.isEmpty()) {
            Toast.makeText(this, "Enter a weight before saving.", Toast.LENGTH_SHORT).show();
            return;
        }

        double loggedWeight;

        try {
            loggedWeight = Double.parseDouble(weightText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
            return;
        }

        String currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
        boolean inserted = dbHelper.addWeight(loggedInUserId, loggedWeight, currentDate);

        if (inserted) {
            Toast.makeText(this, "Weight log added.", Toast.LENGTH_SHORT).show();
            etWeightInput.setText("");
            refreshWeightLogList();
            evaluateGoalAlert(loggedWeight);
        } else {
            Toast.makeText(this, "Unable to save weight log.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshWeightLogList() {
        logDisplayList.clear();
        logIdList.clear();

        Cursor cursor = dbHelper.getWeights(loggedInUserId);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_VALUE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOG_DATE));

                logIdList.add(id);
                logDisplayList.add("Weight: " + weight + " | Date: " + date);
            } while (cursor.moveToNext());
        } else {
            logDisplayList.add("No weight logs yet. Add your first entry above.");
        }

        cursor.close();
        listAdapter.notifyDataSetChanged();
    }

    private void showUpdateDialog(int weightId) {
        final EditText updateInput = new EditText(this);
        updateInput.setHint("Enter updated weight");
        updateInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        updateInput.setPadding(50, 20, 50, 20);

        new AlertDialog.Builder(this)
                .setTitle("Update Weight Log")
                .setMessage("Enter the corrected weight value.")
                .setView(updateInput)
                .setPositiveButton("Update", (dialog, which) -> {
                    String updatedText = updateInput.getText().toString().trim();

                    if (updatedText.isEmpty()) {
                        Toast.makeText(this, "Update canceled. No value entered.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double updatedWeight;

                    try {
                        updatedWeight = Double.parseDouble(updatedText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid weight value.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String updatedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                    boolean updated = dbHelper.updateWeight(weightId, updatedWeight, updatedDate);

                    if (updated) {
                        Toast.makeText(this, "Weight log updated.", Toast.LENGTH_SHORT).show();
                        refreshWeightLogList();
                        evaluateGoalAlert(updatedWeight);
                    } else {
                        Toast.makeText(this, "Unable to update weight log.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmDelete(int weightId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Log")
                .setMessage("Are you sure you want to delete this weight entry?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean deleted = dbHelper.deleteWeight(weightId);

                    if (deleted) {
                        Toast.makeText(this, "Weight log deleted.", Toast.LENGTH_SHORT).show();
                        refreshWeightLogList();
                    } else {
                        Toast.makeText(this, "Unable to delete weight log.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void evaluateGoalAlert(double loggedWeight) {
        String goalText = etGoalWeight.getText().toString().trim();
        String phoneText = etPhoneNumber.getText().toString().trim();

        if (goalText.isEmpty() || phoneText.isEmpty()) {
            return;
        }

        double goalWeight;

        try {
            goalWeight = Double.parseDouble(goalText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Goal weight must be a valid number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (loggedWeight <= goalWeight) {
            sendSmsAlert(phoneText, loggedWeight);
        }
    }

    private void sendSmsAlert(String phoneNumber, double currentWeight) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String message = "Congratulations! You reached your goal weight. Current logged weight: " + currentWeight;
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Goal reached! SMS notification sent.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS could not be sent.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted. Weight was still saved.", Toast.LENGTH_LONG).show();
        }
    }

    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS notifications enabled.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS denied. The app will continue without notifications.", Toast.LENGTH_LONG).show();
            }
        }
    }
}